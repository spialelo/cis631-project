-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: njitfitnessorg
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `classregister`
--

DROP TABLE IF EXISTS `classregister`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8 ;
CREATE TABLE `classregister` (
  `Mid` varchar(45) NOT NULL,
  `Class_id` varchar(45) NOT NULL,
  PRIMARY KEY (`Mid`,`Class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classregister`
--

LOCK TABLES `classregister` WRITE;
/*!40000 ALTER TABLE `classregister` DISABLE KEYS */;
INSERT INTO `classregister` VALUES ('NJ001','c0'),('NJ001','g1'),('NJ001','w0'),('NJ003','c0'),('NJ003','c4'),('NJ003','g1'),('NJ003','g7'),('NJ003','w0'),('NJ003','w5'),('NJ003','y3'),('NJ004','c0'),('NJ004','c4'),('NJ004','g7'),('NJ004','w0'),('NJ004','w2'),('NJ004','w5'),('NJ005','c0'),('NJ005','c1'),('NJ005','c4'),('NJ005','g1'),('NJ005','g7'),('NJ005','w0'),('NJ005','w2'),('NJ005','w5'),('NJ005','y5'),('NJ006','c0'),('NJ006','c4'),('NJ006','w5'),('NJ006','y3'),('NJ007','g7'),('NJ007','w5'),('NJ008','c0'),('NJ008','y3'),('NJ009','c1'),('NJ009','g7'),('NJ009','w2'),('NJ009','w5'),('NJ009','y3'),('NJ009','y5'),('NJ010','c1'),('NJ010','g7'),('NJ010','w2'),('NJ010','w3'),('NJ010','w5'),('NJ010','y1'),('NJ010','y3'),('NJ010','y5'),('NJ011','c0'),('NJ012','c0'),('NJ012','c4'),('NJ012','g7'),('NJ012','w2'),('NJ012','w5'),('NJ012','y3'),('NJ013','c4'),('NJ013','w0'),('NJ013','w5'),('NJ013','y5'),('NJ014','g6'),('NJ014','g7'),('NJ014','w2'),('NJ014','w5'),('NJ014','y3'),('NJ015','g7'),('NJ015','w2'),('NJ015','y5'),('NJ016','c1'),('NJ016','g7'),('NJ016','y3'),('NJ016','y5'),('NJ017','c1'),('NJ017','g1'),('NJ017','g3'),('NJ017','w2'),('NJ017','w3'),('NJ017','y2'),('NJ017','y3'),('NJ017','y5'),('NJ018','w2'),('NJ019','g7'),('NJ019','w0'),('NJ019','w2'),('NJ019','y3'),('NJ020','g1'),('NJ020','w2'),('NJ020','y3'),('NJ020','y5'),('NJ021','c0'),('NJ021','c1'),('NJ021','y3'),('NJ021','y5'),('NJ022','c1'),('NJ022','w2'),('NJ022','y3'),('NJ022','y5'),('NJ023','w0'),('NJ023','y3'),('NJ024','g1'),('NJ024','g7'),('NJ025','w2'),('NJ025','y3');
/*!40000 ALTER TABLE `classregister` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-03  4:38:55
