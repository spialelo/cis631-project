-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: njitfitnessorg
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8 ;
CREATE TABLE `member` (
  `Mid` varchar(5) NOT NULL,
  `M_name` varchar(45) NOT NULL,
  `Address` varchar(45) NOT NULL,
  `Mtype` varchar(12) NOT NULL,
  PRIMARY KEY (`Mid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` VALUES ('NJ001','Rick','12 Bridge Ave','Family'),('NJ002','Nicole','12 Bridge Ave','Family'),('NJ003','Susan','12 Bridge Ave','Family'),('NJ004','Phil','213 Broad St','VIP'),('NJ005','Doug','908 Ocean Ave','Senior'),('NJ006','Raph','431 Florence Bvld','Senior'),('NJ007','Dan','908 Ocean Ave','Senior'),('NJ008','Gary','513 Ocean Ave','VIP'),('NJ009','Jim','61 Stephen St','Senior'),('NJ010','Keith','101 Collins Ave','VIP'),('NJ011','Norm','82 Pearl St','Family'),('NJ012','Kelly','82 Pearl St','Family'),('NJ013','Dolly','82 Pearl St','Family'),('NJ014','Meghan','82 Pearl St','Family'),('NJ015','Erica','91 Rodman Ave','Student'),('NJ016','Steve','900 Clifford Ave','Student'),('NJ017','Joe','815 Maple Ave','VIP'),('NJ018','Marideth','6 Branchport','Student'),('NJ019','Lace','331 Edwards Ave','Student'),('NJ020','Nick','17 Atlantic Ave','Student'),('NJ021','John','152 Compton Bvld','VIP'),('NJ022','Robert','15 Britney Ln','VIP'),('NJ023','David','522 Harrison Ave','Student'),('NJ024','Nelson','431 Mountain St','Ordinary'),('NJ025','Charles','5 Garnett Ln','Ordinary'),('NJ026','Deb','676 Broad St','VIP'),('NJ027','Ev','1 Broadway Ave','Ordinary'),('NJ028','Mike','45 MLK Bvld','Ordinary'),('NJ029','Shaq','617 Water Rd','Ordinary'),('NJ030','Kobe','80 Chestnut','VIP');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-03  4:38:56
