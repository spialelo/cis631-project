-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: njitfitnessorg
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `exercise_class`
--

DROP TABLE IF EXISTS `exercise_class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8 ;
CREATE TABLE `exercise_class` (
  `Class_id` varchar(45) NOT NULL,
  `Exe_id` int(11) NOT NULL,
  `Building` varchar(25) DEFAULT NULL,
  `Room` int(2) DEFAULT NULL,
  PRIMARY KEY (`Class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exercise_class`
--

LOCK TABLES `exercise_class` WRITE;
/*!40000 ALTER TABLE `exercise_class` DISABLE KEYS */;
INSERT INTO `exercise_class` VALUES ('c0',16,'Cullimore',651),('c1',20,'Cullimore',654),('c2',21,'Fenster Hall',456),('c3',22,'Fenster Hall',789),('c4',23,'Colton',411),('g0',35,'Colton',123),('g1',10,'Cullimore',743),('g2',41,'Fenster Hall',400),('g3',42,'Campbell',101),('g4',43,'Fenster Hall',300),('g5',44,'Cullimore',831),('g6',45,'Colton',411),('g7',46,'Fenster Hall',400),('w0',24,'Cullimore',716),('w1',30,'Fenster Hall',200),('w2',31,'Colton',213),('w3',32,'Cullimore',743),('w4',33,'Fenster Hall',300),('w5',34,'Campbell',101),('y1',10,'Campbell',101),('y2',11,'Colton',123),('y3',12,'Campbell',210),('y4',13,'Cullimore',716),('y5',14,'Colton',212),('y6',15,'Fenster Hall',123);
/*!40000 ALTER TABLE `exercise_class` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-03  4:38:59
