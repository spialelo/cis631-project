DELETE FROM `new_schema`.`teaches` WHERE (`Instr_id` = 'C30') and (`Class_id` = 'z1');
