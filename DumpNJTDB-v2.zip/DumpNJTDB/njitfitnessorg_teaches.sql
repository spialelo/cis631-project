-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: njitfitnessorg
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `teaches`
--

DROP TABLE IF EXISTS `teaches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8 ;
CREATE TABLE `teaches` (
  `Date` date DEFAULT NULL,
  `Duration` time DEFAULT NULL,
  `Start_time` time DEFAULT NULL,
  `Class_id` varchar(45) NOT NULL,
  `Instr_id` varchar(45) NOT NULL,
  PRIMARY KEY (`Instr_id`,`Class_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teaches`
--

LOCK TABLES `teaches` WRITE;
/*!40000 ALTER TABLE `teaches` DISABLE KEYS */;
INSERT INTO `teaches` VALUES ('2019-08-08','01:00:00','08:00:00','c0','C10'),('2019-08-08','02:15:00','08:00:00','c1','C20'),('2019-08-08','00:30:00','09:00:00','c2','C20'),('2019-08-09','01:00:00','10:15:00','c3','C25'),('2019-08-09','02:15:00','11:40:00','c4','C25'),('2019-08-10','02:15:00','09:45:00','g0','C25'),('2019-08-10','00:30:00','12:00:00','g1','C30'),('2019-08-11','01:00:00','09:00:00','g2','C40'),('2019-08-11','00:30:00','05:45:00','g3','C50'),('2019-08-12','02:15:00','06:15:00','g4','C60'),('2019-08-12','00:35:00','06:15:00','g5','C85'),('2019-08-12','01:00:00','06:45:00','g6','C99'),('2019-08-12','01:00:00','09:00:00','g7','C99'),('2019-08-13','00:50:00','07:20:00','w0','E100'),('2019-09-01','01:15:00','11:50:00','y6','E100'),('2019-09-10','02:15:00','06:00:00','w1','E110'),('2019-09-03','00:20:00','10:15:00','w2','E110'),('2019-09-04','01:00:00','12:10:00','w3','E115'),('2019-09-13','00:55:00','11:30:00','w4','E123'),('2019-10-03','00:50:00','09:00:00','w5','E125'),('2019-10-14','02:15:00','08:00:00','y1','E125'),('2019-10-31','01:15:00','08:45:00','y2','E175'),('2019-11-10','00:40:00','09:05:00','y3','E180'),('2019-12-04','01:00:00','11:35:00','y4','E180'),('2019-12-19','00:50:00','12:00:00','y5','E199');
/*!40000 ALTER TABLE `teaches` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-03  4:38:58
