-- MySQL dump 10.13  Distrib 8.0.16, for Win64 (x86_64)
--
-- Host: localhost    Database: njitfitnessorg
-- ------------------------------------------------------
-- Server version	8.0.16

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
 SET NAMES utf8 ;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `exercise`
--

DROP TABLE IF EXISTS `exercise`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
 SET character_set_client = utf8 ;
CREATE TABLE `exercise` (
  `Exe_id` int(11) NOT NULL,
  `Exe_type` varchar(45) DEFAULT NULL,
  `Exe_name` varchar(45) DEFAULT NULL,
  `Exe_description` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`Exe_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `exercise`
--

LOCK TABLES `exercise` WRITE;
/*!40000 ALTER TABLE `exercise` DISABLE KEYS */;
INSERT INTO `exercise` VALUES (10,'Yoga','Lunges',NULL),(11,'Yoga','Warrior Poses',NULL),(12,'Yoga','Prayer mudra',NULL),(13,'Yoga','Bird Poses',NULL),(14,'Yoga','Frog Poses',NULL),(15,'Yoga','Kneeling reverse prayer',NULL),(16,'Yoga','Reclinded hero poses',NULL),(20,'Cardio','Jogging',NULL),(21,'Cardio','Jump Rope',NULL),(22,'Cardio','Burpees',NULL),(23,'Cardio','Squat thrusts',NULL),(24,'Cardio','Jumping jacks',NULL),(30,'Weights','Seated rows',NULL),(31,'Weights','Bench Press',NULL),(32,'Weights','Bicep curls',NULL),(33,'Weights','Quad Extensions',NULL),(34,'Weights','Leg press',NULL),(35,'Weights','Deadlift',NULL),(40,'Gym','Tennis',NULL),(41,'Gym','Basketball',NULL),(42,'Gym','Volleyball',NULL),(43,'Gym','Floor Hockey',NULL),(44,'Gym','Racket ball',NULL),(45,'Gym','Flag football',NULL),(46,'Gym','Soccer',NULL);
/*!40000 ALTER TABLE `exercise` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-08-03  4:38:59
