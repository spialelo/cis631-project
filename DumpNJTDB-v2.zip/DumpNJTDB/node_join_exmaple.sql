SELECT * FROM new_schema.instructor AS I
JOIN new_schema.employee AS E ON I.Instr_id = E.Empid;
